package com.sample.springdemoproject.xmlbased.controller;

import com.sample.springdemoproject.xmlbased.service.VodafoneEmployeeService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestDISample {


    public static void main(final String[] args) throws ClassNotFoundException {
        final ApplicationContext applicationContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
/*        final AirtelEmployeeService employeeService = (AirtelEmployeeService) applicationContext.getBean("employeeService");
        System.out.println(employeeService);*/

        //------ Constructor Injection
/*
        final JoiEmployeeService joiEmployeeService = (JoiEmployeeService) applicationContext.getBean("jioEmployeeService");
        System.out.println(joiEmployeeService);
*/

        final VodafoneEmployeeService vodafoneEmployeeService =
                (VodafoneEmployeeService) applicationContext.getBean("vodafoneEmployeeService");
        System.out.println(vodafoneEmployeeService);
        System.out.println(vodafoneEmployeeService.getName());
    }

}
