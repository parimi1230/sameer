package com.sample.springdemoproject.annotationbased.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy
@ComponentScan("com.sample.springdemoproject.annotationbased.service")
public class AppConfig {

/*    @Bean
    public Employee getEmployee(){
        final Employee employee = new Employee();
        employee.setId(123);
        employee.setName("Ramesh");
        return employee;
    }*/

}
