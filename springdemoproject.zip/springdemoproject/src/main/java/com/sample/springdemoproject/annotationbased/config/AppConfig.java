package com.sample.springdemoproject.annotationbased.config;

import com.sample.springdemoproject.annotationbased.modal.Employee;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.sample.springdemoproject.annotationbased.service")
public class AppConfig {

/*    @Bean
    public Employee getEmployee(){
        final Employee employee = new Employee();
        employee.setId(123);
        employee.setName("Ramesh");
        return employee;
    }*/

}
