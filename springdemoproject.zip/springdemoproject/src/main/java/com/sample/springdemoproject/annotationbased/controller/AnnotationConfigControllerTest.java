package com.sample.springdemoproject.annotationbased.controller;

import com.sample.springdemoproject.annotationbased.config.AppConfig;
import com.sample.springdemoproject.annotationbased.service.EmployeeDeciderService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class AnnotationConfigControllerTest {

    public static void main(final String[] args) {
        final ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);

/*        final VodafoneEmployeeService service = (VodafoneEmployeeService)applicationContext.getBean("employeeService");
        System.out.println(service);
        System.out.println(service.getName());*/

        final EmployeeDeciderService deciderService = (EmployeeDeciderService) applicationContext.getBean("employeeDeciderService");
        System.out.println(deciderService);

    }

}
