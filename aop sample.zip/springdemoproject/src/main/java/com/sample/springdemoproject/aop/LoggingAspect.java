package com.sample.springdemoproject.aop;


public class LoggingAspect {



}
