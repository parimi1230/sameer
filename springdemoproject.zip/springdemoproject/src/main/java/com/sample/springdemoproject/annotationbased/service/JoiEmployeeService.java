package com.sample.springdemoproject.annotationbased.service;


import com.sample.springdemoproject.annotationbased.modal.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

@Service
@Lazy
public class JoiEmployeeService implements EmployeeService {

    @Autowired(required = false)
    private Employee employee;

    private String serviceName;

    public JoiEmployeeService(){
    }

    public JoiEmployeeService(final Employee employee, final String serviceName) {
        this.employee = employee;
        this.serviceName = serviceName;
    }

    @Override
    public String getName() {
        return "Jio";
    }

    @Override
    public String getLocation() {
        return "JioHyderabad";
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    @Override
    public String toString() {
        return "JoiEmployeeService{" +
                "employee=" + employee +
                ", serviceName='" + serviceName + '\'' +
                '}';
    }
}
