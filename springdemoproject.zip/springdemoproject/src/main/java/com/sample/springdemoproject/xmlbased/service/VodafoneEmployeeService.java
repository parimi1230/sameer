package com.sample.springdemoproject.xmlbased.service;


import org.springframework.stereotype.Service;

@Service
public class VodafoneEmployeeService implements EmployeeService{

    @Override
    public String getName() {
        return "Vodafone";
    }

    @Override
    public String getLocation() {
        return "VodaHyderabad";
    }
}
