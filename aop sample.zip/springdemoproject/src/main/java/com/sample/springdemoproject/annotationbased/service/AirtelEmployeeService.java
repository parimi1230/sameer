package com.sample.springdemoproject.annotationbased.service;


import com.sample.springdemoproject.annotationbased.modal.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AirtelEmployeeService implements EmployeeService {

    @Autowired(required = false)
    private Employee employee;

    private String serviceName;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(final Employee employee) {
        this.employee = employee;
    }

    @Override
    public String getName() {
        return "Airtel";
    }

    @Override
    public String getLocation() {
        return "AirtelHyderabad";
    }

    @Override
    public String toString() {
        return "AirtelEmployeeService{" +
                "serviceName='" + serviceName + '\'' +
                ", employee=" + employee +
                '}';
    }
}
