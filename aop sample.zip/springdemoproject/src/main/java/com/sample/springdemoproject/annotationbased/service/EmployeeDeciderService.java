package com.sample.springdemoproject.annotationbased.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeDeciderService {

    @Autowired
    private List<EmployeeService> employeeServices;

    public List<EmployeeService> getEmployeeServices() {
        return employeeServices;
    }

    public void setEmployeeServices(final List<EmployeeService> employeeServices) {
        this.employeeServices = employeeServices;
    }

    @Override
    public String toString() {
        return "EmployeeDeciderService{" +
                "employeeServices=" + employeeServices +
                '}';
    }
}

