package com.sample.springdemoproject.xmlbased.service;


public interface EmployeeService {

    String getName();
    String getLocation();
}
