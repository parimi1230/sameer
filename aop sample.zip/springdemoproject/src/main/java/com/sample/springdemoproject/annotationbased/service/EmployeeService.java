package com.sample.springdemoproject.annotationbased.service;


public interface EmployeeService {

    String getName();
    String getLocation();
}
