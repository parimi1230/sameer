package com.sample.springdemoproject.xmlbased.service;


import com.sample.springdemoproject.xmlbased.modal.Employee;

public class AirtelEmployeeService implements EmployeeService {

    private Employee employee;

    private String serviceName;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(final Employee employee) {
        this.employee = employee;
    }

    @Override
    public String getName() {
        return "Airtel";
    }

    @Override
    public String getLocation() {
        return "AirtelHyderabad";
    }

    @Override
    public String toString() {
        return "AirtelEmployeeService{" +
                "serviceName='" + serviceName + '\'' +
                ", employee=" + employee +
                '}';
    }
}
