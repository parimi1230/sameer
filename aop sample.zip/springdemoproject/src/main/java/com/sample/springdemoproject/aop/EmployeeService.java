package com.sample.springdemoproject.aop;


import com.sample.springdemoproject.annotationbased.modal.Employee;

public class EmployeeService {

    public Employee getEmployee(){
        System.out.println("I am in getEmployee");
        final Employee employee = new Employee();
        return employee;
    }


    public void updateEmployee(int a, int b){
        System.out.println("I am in updateEmployee");
        System.out.println("Arguments -> "+ a+ " "+ b);
    }


    public void deleteEmployee(final int empId){
        System.out.println("I am in deleteEmployee");
        System.out.println("Arguments -> "+ empId);
    }


    public void createEmployee(){
        System.out.println("I am in createEmployee");
    }

}
